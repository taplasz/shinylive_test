"""
This module is internal; public-facing imports should not rely on its location.
"""

from ._main import ShinyTestGenerator

__all__ = ["ShinyTestGenerator"]
